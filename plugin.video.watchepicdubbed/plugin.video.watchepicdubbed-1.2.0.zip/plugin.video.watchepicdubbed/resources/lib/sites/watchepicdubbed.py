# -*- coding: UTF-8 -*-
"""
    Copyright (C) 2014  smokdpi

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


""" Site information used for main menu if more than 1 site """
title = 'WatchEpicDubbed'
image = ''
art = ''
order = 1


class Site():

    def __init__(self, __params_):
        import re
        from addon import Addon
        from addondict import AddonDict as XBMCDict
        from BeautifulSoup import BeautifulSoup, SoupStrainer, Comment

        a = Addon()
        __site_ = self.__module__
        __mode_ = __params_['mode']

        __home_url_ = 'http://www.dubbedanimehd.net'
        __series_url_ = __home_url_ + '/dubbed-anime'
        __movies_url_ = __home_url_ + '/anime-movie-list'


        if __mode_ == 'main':
            __item_list_ = [{'site': __site_, 'mode': 'list_index', 'title': a.language(30001), 'content': 'tvshows',
                            'url': __series_url_, 'cover_url': a.image(), 'backdrop_url': a.art(), 'type': 3},
                            {'site': __site_, 'mode': 'list_index', 'title': a.language(30002), 'content': 'movies',
                            'url': __movies_url_, 'cover_url': a.image(), 'backdrop_url': a.art(), 'type': 3},
                            {'site': __site_, 'mode': 'list_latest', 'title': a.language(30004), 'content': 'episodes',
                            'url': __home_url_, 'cover_url': a.image(), 'backdrop_url': a.art(), 'type': 3},
                            {'site': __site_, 'mode': 'list_ongoing', 'title': a.language(30006), 'content': 'tvshows',
                            'url': __home_url_, 'cover_url': a.image(), 'backdrop_url': a.art(), 'type': 3},
                            {'site': __site_, 'mode': 'list_added', 'title': a.language(30005), 'content': 'tvshows',
                            'url': __home_url_, 'cover_url': a.image(), 'backdrop_url': a.art(), 'type': 3}]
            __item_list_.extend(a.favs_hist_menu(__site_))
            __item_list_.extend(a.extended_menu())
            a.add_items(__item_list_)
            a.end_of_directory()

        elif __mode_ == 'list_index':
            __html_ = a.get_page(__params_['url'])
            __soup_ = None
            __item_list_ = []
            __xbmcdict_ = {}
            __params_['context'] = 0
            if __params_['content'] == 'tvshows':
                __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'class': 'tab-wrapper'}),
                                        convertEntities=BeautifulSoup.HTML_ENTITIES)
            elif __params_['content'] == 'movies':
                __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'id': 'main'}),
                                        convertEntities=BeautifulSoup.HTML_ENTITIES)
            if __soup_:
                __xbmcdict_ = XBMCDict().update(__params_)
                # for __ul_ in __soup_.findAll('ul', {'class': 'anime-list'}):
                for __item_ in __soup_.findAll('li'):
                    __dict_ = __xbmcdict_.copy()
                    __dict_['mode'] = 'list_episodes'
                    __dict_['title'] = __item_.a.string.encode('UTF-8')
                    __dict_['url'] = __item_.a.get('href').encode('UTF-8')
                    __dict_['sub_site'] = __site_
                    __item_list_.extend([__dict_])
            if __item_list_:
                a.add_items(__item_list_)
                a.end_of_directory(__xbmcdict_['content'], __xbmcdict_.media_type(), 10)

        elif __mode_ == 'list_ongoing':
            __html_ = a.get_page(__params_['url'])
            __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'id': 'main'}),
                                    convertEntities=BeautifulSoup.HTML_ENTITIES)
            __item_list_ = []
            __params_['context'] = 0
            __xbmcdict_ = XBMCDict().update(__params_)
            try: __ul_ = __soup_.findAll('div', {'class': 'Lcont'})[1].ul
            except: __ul_ = None
            if __ul_:
                for __li_ in __ul_.findAll('li'):
                    if __li_.a:
                        __dict_ = __xbmcdict_.copy()
                        __dict_['title'] = __li_.a.contents[0].encode('UTF-8').strip()
                        __dict_['tvshowtitle'] = __dict_['title']
                        __dict_['originaltitle'] = __dict_['title']
                        __dict_['mode'] = 'list_episodes'
                        if re.match('.*movie[^s].*', __dict_['title'].lower()):
                            __dict_['content'] = 'movies'
                        elif re.match('.*season\s*[0-9]+.*', __dict_['title'].lower()):
                            __dict_['season'] = int(re.search('season\s*([0-9]+)', __dict_['title'].lower()).group(1))
                        __dict_['url'] = __li_.a.get('href')
                        if __dict_['url'].startswith('/'): __dict_['url'] = __home_url_ + __dict_['url']
                        __dict_['sub_site'] = __site_
                        __item_list_.extend([__dict_])
            if __item_list_:
                a.add_items(__item_list_)
                a.end_of_directory(__xbmcdict_['content'], __xbmcdict_.media_type())

        elif __mode_ == 'list_added':
            __html_ = a.get_page(__params_['url'])
            __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'id': 'main'}),
                                    convertEntities=BeautifulSoup.HTML_ENTITIES)
            __item_list_ = []
            __params_['context'] = 0
            __xbmcdict_ = XBMCDict().update(__params_)
            try: __ul_ = __soup_.findAll('div', {'class': 'Lcont'})[0].ul
            except: __ul_ = None
            if __ul_:
                for __li_ in __ul_.findAll('li'):
                    if __li_.a:
                        __dict_ = __xbmcdict_.copy()
                        __dict_['title'] = __li_.a.contents[0].encode('UTF-8').strip()
                        __dict_['tvshowtitle'] = __dict_['title']
                        __dict_['originaltitle'] = __dict_['title']
                        __dict_['mode'] = 'list_episodes'
                        if re.match('.*movie[^s].*', __dict_['title'].lower()):
                            __dict_['content'] = 'movies'
                        elif re.match('.*season\s*[0-9]+.*', __dict_['title'].lower()):
                            __dict_['season'] = int(re.search('season\s*([0-9]+)', __dict_['title'].lower()).group(1))
                        __dict_['url'] = __li_.a.get('href')
                        if __dict_['url'].startswith('/'): __dict_['url'] = __home_url_ + __dict_['url']
                        __dict_['url'] = __dict_['url'].replace('/anime/', '/watch/')
                        __dict_['sub_site'] = __site_
                        __item_list_.extend([__dict_])
            if __item_list_:
                a.add_items(__item_list_)
                a.end_of_directory(__xbmcdict_['content'], __xbmcdict_.media_type())

        elif __mode_ == 'list_latest':
            __html_ = a.get_page(__params_['url'])
            __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'id': 'main'}),
                                    convertEntities=BeautifulSoup.HTML_ENTITIES)
            __item_list_ = []
            __params_['type'] = 0
            __params_['context'] = 0
            __xbmcdict_ = XBMCDict().update(__params_)
            for __item_ in __soup_.findAll('div', {'class': 'episode'}):
                if __item_.a.get('href'):
                    __dict_ = __xbmcdict_.copy()
                    __dict_['title'] = __item_.find('h3').a.contents[0].encode('UTF-8').strip()
                    __dict_['tvshowtitle'] = __dict_['title']
                    __dict_['originaltitle'] = __dict_['title']
                    __dict_['mode'] = 'play'
                    if re.match('.*episode\s*[0-9]+.*', __dict_['title'].lower()):
                        __dict_['episode'] = int(re.search('episode\s*([0-9]+)', __dict_['title'].lower()).group(1))
                        if re.match('.*season\s*[0-9]+.*', __dict_['title'].lower()):
                            __dict_['season'] = int(re.search('season\s*([0-9]+)', __dict_['title'].lower()).group(1))
                        try:
                            if int(__dict_['season']) == 0: __dict_['season'] = 1
                        except: pass
                    __dict_['url'] = __item_.a.get('href')
                    __dict_['cover_url'] = __item_.img.get('src')
                    __xbmcdict_['thumb_url'] = __xbmcdict_['cover_url']
                    __xbmcdict_['banner_url'] = __xbmcdict_['cover_url']
                    __xbmcdict_['poster'] = __xbmcdict_['cover_url']
                    __dict_['sub_site'] = __site_
                    __item_list_.extend([__dict_])
            if __item_list_:
                a.add_items(__item_list_)
                a.end_of_directory(__xbmcdict_['content'], __xbmcdict_.media_type())

        elif __mode_ == 'list_episodes':
            __html_ = a.get_page(__params_['url'])
            __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'id': 'main'}),
                                    convertEntities=BeautifulSoup.HTML_ENTITIES)
            if ('movie' in __params_['title'].lower()) or ('movie' in __params_['url']) or (__params_['content'] == 'movies'):
                __params_['content'] = 'movies'
                __params_['duration'] = '75'
            else: __params_['content'] = 'episodes'
            __params_['context'] = 0
            __params_['type'] = 0
            __item_list_ = []
            __xbmcdict_ = XBMCDict().update(__params_)
            __xbmcdict_['mode'] = 'play'
            __xbmcdict_['cover_url'] = __soup_.find('img').get('src')
            __xbmcdict_['thumb_url'] = __xbmcdict_['cover_url']
            __xbmcdict_['banner_url'] = __xbmcdict_['cover_url']
            __xbmcdict_['poster'] = __xbmcdict_['cover_url']
            __xbmcdict_['tvshowtitle'] = __soup_.find('h1').contents[0].encode('UTF-8').strip()
            __xbmcdict_['originaltitle'] = __soup_.find('h1').contents[0].encode('UTF-8').strip()
            __xbmcdict_['status'] = __soup_.find('span', text='Status:').next.strip()
            try: __xbmcdict_['year'] = int(__soup_.find('span', text='Released:').next.strip())
            except: pass
            __item_ = __soup_.find('span', text='Description:').next.strip()
            if __item_:
                __xbmcdict_['plotoutline'] = __item_
                __xbmcdict_['plot'] = __xbmcdict_['plotoutline']
                try:
                    __item_ = __soup_.find('span', {'class': 'desc_more'}).next.strip()
                    if __item_:
                        __xbmcdict_['plot'] += __item_
                except: pass
            try:
                __xbmcdict_['genre'] = __soup_.find('span', text='Genre:').next.encode('UTF-8')
            except:
                pass
            __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'style': 'font-size:14px;'}),
                                    convertEntities=BeautifulSoup.HTML_ENTITIES)
            for __item_ in __soup_.findAll('a', {'href': True}):
                __dict_ = __xbmcdict_.copy()
                __dict_['title'] = __item_.string.encode('UTF-8').strip()
                __dict_['url'] = __item_.get('href')
                if re.match('.*episode\s*[0-9]+.*', __dict_['title'].lower()):
                    __dict_['episode'] = int(re.search('episode\s*([0-9]+)', __dict_['title'].lower()).group(1))
                    if re.match('.*season\s*[0-9]+.*', __dict_['title'].lower()):
                        __dict_['season'] = int(re.search('season\s*([0-9]+)', __dict_['title'].lower()).group(1))
                    try:
                        if int(__dict_['season']) == 0: __dict_['season'] = 1
                    except: pass
                if 'movie' in __dict_['title'].lower():
                    __dict_['content'] = 'movies'
                    __dict_['duration'] = '75'
                __dict_['sub_site'] = __site_
                __item_list_.extend([__dict_])
            if __item_list_:
                a.add_items(__item_list_)
                a.end_of_directory(__xbmcdict_['content'], __xbmcdict_.media_type(), 10)

        elif __mode_ == 'play':
            __html_ = a.get_page(__params_['url'])
            __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'id': 'main'}),
                                    convertEntities=BeautifulSoup.HTML_ENTITIES)
            __backup_ = None
            __item_list_ = []
            __xbmcdict_ = XBMCDict().update(__params_)
            __item_ = __soup_.find('iframe', {'id': 'video'})
            if __item_:
                __dict_ = __xbmcdict_.copy()
                __dict_['url'] = __item_.get('src')
                if __dict_['url']: __item_list_.extend([__dict_])
                try: __backup_ = __soup_.find('a', href=True, text=re.compile("^source 2$", re.I)).parent.get('href').encode('UTF-8')
                except: pass
                if __backup_:
                    if '//' not in __backup_: __backup_ = __home_url_ + '/' + __backup_
                    __html_ = a.get_page(__backup_)
                    __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'id': 'main'}),
                                            convertEntities=BeautifulSoup.HTML_ENTITIES)
                    __item_ = __soup_.find('iframe', {'id': 'video'})
                    if __item_:
                        __dict_ = __xbmcdict_.copy()
                        __dict_['url'] = __item_.get('src')
                        if __dict_['url']: __item_list_.extend([__dict_])
            if __item_list_:
                from playback import Playback
                Playback().choose_sources(__item_list_)
            else: a.alert(a.language(30904, True))