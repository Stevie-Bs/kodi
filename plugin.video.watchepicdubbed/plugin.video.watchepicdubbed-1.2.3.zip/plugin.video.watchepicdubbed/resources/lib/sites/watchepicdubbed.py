# -*- coding: UTF-8 -*-
"""
    Copyright (C) 2014  smokdpi

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

""" Site information used for main menu if more than 1 site """
title = 'WatchEpicDubbed'
image = 'watchepicdubbed-icon.png'
art = 'watchepicdubbed-fanart.jpg'
order = 3


class Site:
    def __init__(self, params):
        import re
        from addon import Addon
        from addondict import AddonDict as XBMCDict
        from BeautifulSoup import BeautifulSoup, SoupStrainer, Comment

        a = Addon()
        site = self.__module__
        mode = params['mode']

        home_url = 'http://www.dubbedanimehd.net'
        series_url = home_url + '/dubbed-anime'
        movies_url = home_url + '/anime-movie-list'

        if mode == 'main':
            item_list = [{'site': site, 'mode': 'list_index', 'title': a.language(30031), 'content': 'tvshows',
                          'url': series_url, 'cover_url': a.image('allseries.png'), 'backdrop_url': a.art(), 'type': 3},
                         {'site': site, 'mode': 'list_index', 'title': a.language(30032), 'content': 'movies',
                          'url': movies_url, 'cover_url': a.image('allmovies.png'), 'backdrop_url': a.art(), 'type': 3},
                         {'site': site, 'mode': 'list_latest', 'title': a.language(30034), 'content': 'episodes',
                          'url': home_url, 'cover_url': a.image('latestepisodes.png'), 'backdrop_url': a.art(),
                          'type': 3},
                         {'site': site, 'mode': 'list_ongoing', 'title': a.language(30036), 'content': 'tvshows',
                          'url': home_url, 'cover_url': a.image('ongoingseries.png'), 'backdrop_url': a.art(),
                          'type': 3},
                         {'site': site, 'mode': 'list_added', 'title': a.language(30035), 'content': 'tvshows',
                          'url': home_url, 'cover_url': a.image('upcomingepisodes.png'), 'backdrop_url': a.art(),
                          'type': 3}]
            item_list.extend(a.favs_hist_menu(site))
            item_list.extend(a.extended_menu())
            a.add_items(item_list)
            a.end_of_directory()

        elif mode == 'list_index':
            html = a.get_page(params['url'])
            soup = None
            item_list = []
            xbmcdict = {}
            params['context'] = 0
            if params['content'] == 'tvshows':
                soup = BeautifulSoup(html, parseOnlyThese=SoupStrainer('div', {'class': 'tab-wrapper'}),
                                     convertEntities=BeautifulSoup.HTML_ENTITIES)
            elif params['content'] == 'movies':
                soup = BeautifulSoup(html, parseOnlyThese=SoupStrainer('div', {'id': 'main'}),
                                     convertEntities=BeautifulSoup.HTML_ENTITIES)
            if soup:
                xbmcdict = XBMCDict().update(params)
                # for ul in soup.findAll('ul', {'class': 'anime-list'}):
                for item in soup.findAll('li'):
                    _dict = xbmcdict.copy()
                    _dict['mode'] = 'list_episodes'
                    _dict['title'] = item.a.string.encode('UTF-8')
                    _dict['url'] = item.a.get('href').encode('UTF-8')
                    _dict['sub_site'] = site
                    item_list.extend([_dict])
            if item_list:
                a.add_items(item_list)
                a.end_of_directory(default_sort=10)

        elif mode == 'list_ongoing':
            html = a.get_page(params['url'])
            soup = BeautifulSoup(html, parseOnlyThese=SoupStrainer('div', {'id': 'main'}),
                                 convertEntities=BeautifulSoup.HTML_ENTITIES)
            item_list = []
            params['context'] = 0
            xbmcdict = XBMCDict().update(params)
            try:
                ul = soup.findAll('div', {'class': 'Lcont'})[1].ul
            except:
                ul = None
            if ul:
                for li in ul.findAll('li'):
                    if li.a:
                        _dict = xbmcdict.copy()
                        _dict['title'] = li.a.contents[0].encode('UTF-8').strip()
                        _dict['tvshowtitle'] = _dict['title']
                        _dict['originaltitle'] = _dict['title']
                        _dict['mode'] = 'list_episodes'
                        if re.match('.*movie[^s].*', _dict['title'].lower()):
                            _dict['content'] = 'movies'
                        elif re.match('.*season\s*[0-9]+.*', _dict['title'].lower()):
                            _dict['season'] = int(re.search('season\s*([0-9]+)', _dict['title'].lower()).group(1))
                        _dict['url'] = li.a.get('href')
                        if _dict['url'].startswith('/'): _dict['url'] = home_url + _dict['url']
                        _dict['sub_site'] = site
                        item_list.extend([_dict])
            if item_list:
                a.add_items(item_list)
                a.end_of_directory()

        elif mode == 'list_added':
            html = a.get_page(params['url'])
            soup = BeautifulSoup(html, parseOnlyThese=SoupStrainer('div', {'id': 'main'}),
                                 convertEntities=BeautifulSoup.HTML_ENTITIES)
            item_list = []
            params['context'] = 0
            xbmcdict = XBMCDict().update(params)
            try:
                ul = soup.findAll('div', {'class': 'Lcont'})[0].ul
            except:
                ul = None
            if ul:
                for li in ul.findAll('li'):
                    if li.a:
                        _dict = xbmcdict.copy()
                        _dict['title'] = li.a.contents[0].encode('UTF-8').strip()
                        _dict['tvshowtitle'] = _dict['title']
                        _dict['originaltitle'] = _dict['title']
                        _dict['mode'] = 'list_episodes'
                        if re.match('.*movie[^s].*', _dict['title'].lower()):
                            _dict['content'] = 'movies'
                        elif re.match('.*season\s*[0-9]+.*', _dict['title'].lower()):
                            _dict['season'] = int(re.search('season\s*([0-9]+)', _dict['title'].lower()).group(1))
                        _dict['url'] = li.a.get('href')
                        if _dict['url'].startswith('/'): _dict['url'] = home_url + _dict['url']
                        _dict['url'] = _dict['url'].replace('/anime/', '/watch/')
                        _dict['sub_site'] = site
                        item_list.extend([_dict])
            if item_list:
                a.add_items(item_list)
                a.end_of_directory()

        elif mode == 'list_latest':
            html = a.get_page(params['url'])
            soup = BeautifulSoup(html, parseOnlyThese=SoupStrainer('div', {'id': 'main'}),
                                 convertEntities=BeautifulSoup.HTML_ENTITIES)
            item_list = []
            params['type'] = 0
            params['context'] = 0
            xbmcdict = XBMCDict().update(params)
            for item in soup.findAll('div', {'class': 'episode'}):
                if item.a.get('href'):
                    _dict = xbmcdict.copy()
                    _dict['title'] = item.find('h3').a.contents[0].encode('UTF-8').strip()
                    _dict['tvshowtitle'] = _dict['title']
                    _dict['originaltitle'] = _dict['title']
                    _dict['mode'] = 'play'
                    if re.match('.*episode\s*[0-9]+.*', _dict['title'].lower()):
                        _dict['episode'] = int(re.search('episode\s*([0-9]+)', _dict['title'].lower()).group(1))
                        if re.match('.*season\s*[0-9]+.*', _dict['title'].lower()):
                            _dict['season'] = int(re.search('season\s*([0-9]+)', _dict['title'].lower()).group(1))
                        try:
                            if int(_dict['season']) == 0: _dict['season'] = 1
                        except:
                            pass
                    _dict['url'] = item.a.get('href')
                    _dict['cover_url'] = item.img.get('src')
                    xbmcdict['thumb_url'] = xbmcdict['cover_url']
                    xbmcdict['banner_url'] = xbmcdict['cover_url']
                    xbmcdict['poster'] = xbmcdict['cover_url']
                    _dict['sub_site'] = site
                    item_list.extend([_dict])
            if item_list:
                a.add_items(item_list)
                a.end_of_directory()

        elif mode == 'list_episodes':
            html = a.get_page(params['url'])
            soup = BeautifulSoup(html, parseOnlyThese=SoupStrainer('div', {'id': 'main'}),
                                 convertEntities=BeautifulSoup.HTML_ENTITIES)
            if ('movie' in params['title'].lower()) or ('movie' in params['url']) or (params['content'] == 'movies'):
                params['content'] = 'movies'
                params['duration'] = '4500'
            else:
                params['content'] = 'episodes'
            params['context'] = 0
            params['type'] = 0
            item_list = []
            xbmcdict = XBMCDict().update(params)
            xbmcdict['mode'] = 'play'
            xbmcdict['cover_url'] = soup.find('img').get('src')
            xbmcdict['thumb_url'] = xbmcdict['cover_url']
            xbmcdict['banner_url'] = xbmcdict['cover_url']
            xbmcdict['poster'] = xbmcdict['cover_url']
            xbmcdict['tvshowtitle'] = soup.find('h1').contents[0].encode('UTF-8').strip()
            xbmcdict['originaltitle'] = soup.find('h1').contents[0].encode('UTF-8').strip()
            xbmcdict['status'] = soup.find('span', text='Status:').next.strip()
            try:
                xbmcdict['year'] = int(soup.find('span', text='Released:').next.strip())
            except:
                pass
            item = soup.find('span', text='Description:').next.strip()
            if item:
                xbmcdict['plotoutline'] = item
                xbmcdict['plot'] = xbmcdict['plotoutline']
                try:
                    item = soup.find('span', {'class': 'desc_more'}).next.strip()
                    if item:
                        xbmcdict['plot'] += item
                except:
                    pass
            try:
                xbmcdict['genre'] = soup.find('span', text='Genre:').next.encode('UTF-8')
            except:
                pass
            soup = BeautifulSoup(html, parseOnlyThese=SoupStrainer('div', {'style': 'font-size:14px;'}),
                                 convertEntities=BeautifulSoup.HTML_ENTITIES)
            for item in soup.findAll('a', {'href': True}):
                _dict = xbmcdict.copy()
                _dict['title'] = item.string.encode('UTF-8').strip()
                _dict['url'] = item.get('href')
                if re.match('.*episode\s*[0-9]+.*', _dict['title'].lower()):
                    _dict['episode'] = int(re.search('episode\s*([0-9]+)', _dict['title'].lower()).group(1))
                    if re.match('.*season\s*[0-9]+.*', _dict['title'].lower()):
                        _dict['season'] = int(re.search('season\s*([0-9]+)', _dict['title'].lower()).group(1))
                    try:
                        if int(_dict['season']) == 0: _dict['season'] = 1
                    except:
                        pass
                if 'movie' in _dict['title'].lower():
                    _dict['content'] = 'movies'
                    _dict['duration'] = '4500'
                _dict['sub_site'] = site
                item_list.extend([_dict])
            if item_list:
                a.add_items(item_list)
                a.end_of_directory(default_sort=10)

        elif mode == 'play':
            html = a.get_page(params['url'])
            soup = BeautifulSoup(html, parseOnlyThese=SoupStrainer('div', {'id': 'main'}),
                                 convertEntities=BeautifulSoup.HTML_ENTITIES)
            backup = None
            item_list = []
            xbmcdict = XBMCDict().update(params)
            item = soup.find('iframe', {'id': 'video'})
            if item:
                _dict = xbmcdict.copy()
                _dict['url'] = item.get('src')
                if _dict['url']: item_list.extend([_dict])
                try:
                    backup = soup.find('a', href=True, text=re.compile("^source 2$", re.I)).parent.get('href').encode(
                        'UTF-8')
                except:
                    pass
                if backup:
                    if '//' not in backup: backup = home_url + '/' + backup
                    html = a.get_page(backup)
                    soup = BeautifulSoup(html, parseOnlyThese=SoupStrainer('div', {'id': 'main'}),
                                         convertEntities=BeautifulSoup.HTML_ENTITIES)
                    item = soup.find('iframe', {'id': 'video'})
                    if item:
                        _dict = xbmcdict.copy()
                        _dict['url'] = item.get('src')
                        if _dict['url']: item_list.extend([_dict])
            if item_list:
                from playback import Playback
                Playback().choose_sources(item_list)
            else:
                a.alert(a.language(30904, True))
