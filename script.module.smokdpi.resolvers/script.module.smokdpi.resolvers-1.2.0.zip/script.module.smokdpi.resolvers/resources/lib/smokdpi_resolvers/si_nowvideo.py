"""
    Kodi urlresolver plugin
    Copyright (C) 2014  smokdpi

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


from t0mm0.common.net import Net
from urlresolver.plugnplay.interfaces import UrlResolver
from urlresolver.plugnplay.interfaces import PluginSettings
from urlresolver.plugnplay import Plugin
import re
import urllib


class AaaaNowvideoResolver(Plugin, UrlResolver, PluginSettings):
    implements = [UrlResolver, PluginSettings]
    name = "si_nowvideo"
    domains = ["nowvideo.eu", "nowvideo.ch", "nowvideo.sx", "nowvideo.li"]

    def __init__(self):
        p = self.get_setting('priority') or 100
        self.priority = int(p)
        self.pattern = 'http://(?:www|embed)\.*(nowvideo\.(?:eu|sx|ch|li))/(?:video/|embed\.php\?.*?v=)([0-9A-Za-z]+)'
        self.net = Net()
        self.user_agent = 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko'
        self.net.set_user_agent(self.user_agent)
        self.headers = {'User-Agent': self.user_agent}

    def get_media_url(self, host, media_id):
        web_url = self.get_url(host, media_id)
        self.headers['Referer'] = web_url
        stream_url = None
        html = self.net.http_GET(web_url, headers=self.headers).content
        file_key = re.search('flashvars\.file_key\s*=\s*([^;]+)', html)
        file_id = re.search('flashvars\.file\s*=\s*"([^"]+)', html)
        if file_id:
            file_id = file_id.group(1)
        if file_key:
            file_key = file_key.group(1)
        if file_key and file_id:
            file_key = re.search('var\s+%s\s*=\s*"([^"]+)' % file_key, html)
            if file_key:
                api = 'http://www.nowvideo.sx/api/player.api.php?key=%s&file=%s' % (file_key.group(1), file_id)
                html = self.net.http_GET(api).content
                r = re.search('url=([^&]+)', html)
                if r:
                    stream_url = urllib.unquote(r.group(1))
        if stream_url:
            return '%s|User-Agent=%s' % (stream_url, urllib.quote(self.user_agent))
        else:
            raise UrlResolver.ResolverError('File not found or removed')

    def get_url(self, host, media_id):
        return 'http://embed.nowvideo.sx/embed.php?v=%s' % (media_id)

    def get_host_and_id(self, url):
        r = re.search(self.pattern, url)
        if r: return r.groups()
        else: return False

    def valid_url(self, url, host):
        if self.get_setting('enabled') == 'false': return False
        return re.match(self.pattern, url) or 'nowvideo' in host
