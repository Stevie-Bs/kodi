"""
    Kodi urlresolver plugin
    Copyright (C) 2014  smokdpi

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


from t0mm0.common.net import Net
from urlresolver.plugnplay.interfaces import UrlResolver
from urlresolver.plugnplay.interfaces import PluginSettings
from urlresolver.plugnplay import Plugin
import re
import urllib


class AaaaVideomegaResolver(Plugin, UrlResolver, PluginSettings):
    implements = [UrlResolver, PluginSettings]
    name = "si_videomega"
    domains = ["videomega.tv"]

    def __init__(self):
        p = self.get_setting('priority') or 100
        self.pattern = 'http://(?:www.)?%s/(?:iframe|cdn|validatehash|\?ref=).(?:php|js|.*)\?*' % self.domains[0]
        self.net = Net()
        self.user_agent = 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'
        self.net.set_user_agent(self.user_agent)
        self.headers = {'User-Agent': self.user_agent,
                        'Referer': 'http://%s/' % self.domains[0]}

    def get_media_url(self, host, media_id):
        web_url = self.get_url(host, media_id)
        stream_url = None
        self.headers['Referer'] = web_url
        html = self.net.http_GET(web_url, headers=self.headers).content
        if 'Error connecting to db' in html:
            raise UrlResolver.ResolverError('Error connecting to DB')
        r = re.compile('document.write.unescape."(.+?)"').findall(html)
        if r:
            unescaped_str = urllib.unquote(r[-1])
            r = re.search('file\s*:\s*"(.*?)"', unescaped_str)
            if r:
                stream_url = r.group(1).replace(" ", "%20")
        else:
            s = re.search('<video id="container".+?poster="(.+?)/videos/screenshots/[0-9a-zA-Z]+?\..+?".*?>', html)
            if s:
                stream_url = '%s/v/' % s.group(1)
            r = re.search('<source src=".+?/v/(.+?)" type="video.*?"/>', html)
            if r and stream_url:
                stream_url += r.group(1)
            else:
                stream_url = None
        if stream_url:
            return '%s|User-Agent=%s&Referer=%s&Cookie=%s' % \
                   (stream_url, urllib.quote(self.user_agent),
                    urllib.quote(web_url), urllib.quote(str(self.net.get_cookies())))
        else:
            raise UrlResolver.ResolverError('No playable video found.')

    def get_url(self, host, media_id):
        if len(media_id) == 60:
            web_url = 'http://%s/validatehash.php?hashkey=%s' % (host, media_id)
            html = self.net.http_GET(web_url, headers=self.headers).content
            if 'Error connecting to db' in html:
                raise UrlResolver.ResolverError('Error connecting to DB')
            if 'ref=' in html:
                return 'http://%s/cdn.php?ref=%s' % (host, re.compile('.*?ref="(.+?)".*').findall(html)[0])
            else:
                raise UrlResolver.ResolverError('No playable video found.')
        else:
            return 'http://%s/iframe.php?ref=%s' % (host, media_id)

    def get_host_and_id(self, url):
        r = re.search('//((?:www.)?(?:.+?))/.*(?:\?(?:ref|hashkey)=)([0-9a-zA-Z]+)', url)
        if r: return r.groups()
        else: return False

    def valid_url(self, url, host):
        if self.get_setting('enabled') == 'false': return False
        return re.match(self.pattern, url) or host in self.domains
