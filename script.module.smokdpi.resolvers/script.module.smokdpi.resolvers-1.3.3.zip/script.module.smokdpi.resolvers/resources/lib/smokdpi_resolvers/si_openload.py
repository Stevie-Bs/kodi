"""
    Kodi urlresolver plugin
    Copyright (C) 2014  smokdpi

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


from t0mm0.common.net import Net
from urlresolver.plugnplay.interfaces import UrlResolver
from urlresolver.plugnplay.interfaces import PluginSettings
from urlresolver.plugnplay import Plugin
import urllib
import re
from lib import jsunpack


class AaaaOpenLoadResolver(Plugin, UrlResolver, PluginSettings):
    implements = [UrlResolver, PluginSettings]
    name = "si_openload"
    domains = ["openload.io", "openload.co"]

    def __init__(self):
        p = self.get_setting('priority') or 100
        self.priority = int(p)
        self.pattern = '(http[s]*://.*?openload\.(?:io|co))/(?:embed|f)/([a-zA-Z0-9_-]+?)(?:$|/).*'
        self.net = Net()
        self.user_agent = 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'
        self.net.set_user_agent(self.user_agent)
        self.headers = {'User-Agent': self.user_agent}

    def get_url(self, host, media_id):
        return '%s/embed/%s/' % (host, media_id)

    def get_host_and_id(self, url):
        r = re.search(self.pattern, url)
        if r: return r.groups()
        else: return False

    def valid_url(self, url, host):
        if self.get_setting('enabled') == 'false': return False
        return re.match(self.pattern, url) or self.name in host

    def get_media_url(self, host, media_id):
        web_url = self.get_url(host, media_id)
        self.headers['Referer'] = web_url
        html = self.net.http_GET(web_url, headers=self.headers).content

        r = re.search('<video.*?src=["\'](.+?)["\']', html)
        if r:
            return self.__add_headers_for_kodi(r.group(1))

        r = re.search('\$\("video\s*source"\)\.attr\("src",\s*"(.+?)"\);', html)
        if r:
            return self.__add_headers_for_kodi(r.group(1))

        r = re.search('<source.*?src=["\'](.+?)["\']', html)
        if r:
            return self.__add_headers_for_kodi(r.group(1))

        r = self.__decode_O(html)
        if r:
            return self.__add_headers_for_kodi(r)

        raise UrlResolver.ResolverError('File not found')

    def __add_headers_for_kodi(self, url):
        _referer = urllib.quote_plus('http://%s/' % self.domains[0])
        _user_agent = urllib.quote_plus(self.net._user_agent)
        _cookies = ''
        for _cookie in self.net._cj:
            _cookies += '&Cookie=' + urllib.quote_plus(_cookie.name) + '%3D' + urllib.quote_plus(_cookie.value)
        return '%s|Referer=%s&User-Agent=%s%s' % (url, _referer, _user_agent, _cookies)

    def __decode_O(self, html):
        # tknorris: https://github.com/Eldorados/script.module.urlresolver/blob/master/lib/urlresolver/plugins/openload.py
        try:
            packed_data = re.search('>\s*(eval\s*\(function.*?)\s*</script>', html, re.DOTALL).group(1)
            new_str = re.search("decodeURIComponent\('(.*?)'\)", packed_data).group(1)
            new_str = urllib.unquote(new_str)
            packed_data = re.sub('decodeURIComponent\(.*?\)', "'%s'" % (new_str), packed_data)
            match = re.search(',\s*\((.*?)\)\.split\([\'"](.*?)[\'"]\)', packed_data)
            if match:
                split_str, delim = match.groups()
                new_split_str = eval(split_str)
                new_split_str = new_split_str.replace(delim, '|')
                packed_data = re.sub(',\s*\(.*?\)\.split\(.*?\)', ", '%s'.split('%s')" % (new_split_str, '|'), packed_data)
            html = jsunpack.unpack(packed_data)
            html = html.replace('\\\\', '\\')

            O = {
                '___': 0,
                '$$$$': "f",
                '__$': 1,
                '$_$_': "a",
                '_$_': 2,
                '$_$$': "b",
                '$$_$': "d",
                '_$$': 3,
                '$$$_': "e",
                '$__': 4,
                '$_$': 5,
                '$$__': "c",
                '$$_': 6,
                '$$$': 7,
                '$___': 8,
                '$__$': 9,
                '$_': "constructor",
                '$$': "return",
                '_$': "o",
                '_': "u",
                '__': "t",
            }
            s1 = re.search('o\.\$\(o\.\$\((.*?)\)\(\)\)\(\);', html).group(1)
            s1 = s1.replace(' ', '')
            s1 = s1.replace('(![]+"")', 'false')
            s3 = ''
            for s2 in s1.split('+'):
                if s2.startswith('o.'):
                    s3 += str(O[s2[2:]])
                elif '[' in s2 and ']' in s2:
                    key = s2[s2.find('[') + 3:-1]
                    s3 += s2[O[key]]
                else:
                    s3 += s2[1:-1]

            s3 = s3.replace('\\\\', '\\')
            s3 = s3.decode('unicode_escape')
            s3 = s3.replace('\\/', '/')
            s3 = s3.replace('\\\\"', '"')
            s3 = s3.replace('\\"', '"')
            match = re.search('<source.+?src="([^"]+)', s3)
            return match.group(1)
        except Exception as e:
            raise UrlResolver.ResolverError('Decode-O Parsing Failure: %s' % (e))
