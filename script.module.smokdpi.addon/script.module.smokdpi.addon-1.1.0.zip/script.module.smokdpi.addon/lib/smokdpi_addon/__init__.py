# -*- coding: UTF-8 -*-
"""
    script.module.smokdpi.addon init v0.1.0
    - Add all .py files in __path__ to __ALL__ for Personal Kodi Add-ons
    - Build add-on base menu, plug'n'play sites, lock, settings

    Copyright (C) 2014  smokdpi

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import os
import sys
import re
import xbmc
import xbmcaddon


path = xbmc.translatePath(os.path.join(xbmcaddon.Addon('script.module.smokdpi.addon').getAddonInfo('path'), 'lib', 'smokdpi_addon'))

__files__ = []

for __file__ in os.listdir(path):
    if os.path.isfile(os.path.join(path, __file__)):
        __file__ = re.search('^([a-zA-Z0-9]+[a-zA-Z0-9_\-]+)\.py$', __file__)
        if __file__:
            __files__.extend([__file__.groups()[0]])

__ALL__ = __files__

sys.path.append(path)

__sitepath__ = xbmc.translatePath(os.path.join(xbmc.translatePath('special://home'), 'addons',
                                  xbmcaddon.Addon().getAddonInfo('id'), 'resources', 'lib', 'sites'))
sys.path.append(__sitepath__)

from core import AddonCore

a = AddonCore()
__params__ = a.queries
__param__ = __params__.get('site', 'main')

__check_ = a.disclaimer(a.language(30995), a.name + ' ' + a.language(30994))
if __check_:

    if __param__ == 'main':
        __check_ = False
        if a.is_locked():
            __check_ = a.toggle_lock()
        else: __check_ = True

        if __check_:

            __sites__ = []
            __item_list__ = []
            __site_list__ = []

            for __file__ in os.listdir(__sitepath__):
                if os.path.isfile(os.path.join(__sitepath__, __file__)):
                    __site__ = re.search('^([a-zA-Z0-9]+[a-zA-Z0-9_\-]+)\.py$', __file__)
                    if __site__:
                        __sites__.extend([__site__.groups()[0]])
            if __sites__:
                if len(__sites__) == 1:
                    try:
                        i = __import__(__sites__[0], fromlist=[''])
                        i.Site(__params__)
                    except ImportError: a.error(a.language(30907) + ' ' + a.name)
                elif len(__sites__) > 1:
                    for __site__ in __sites__:
                        try:
                            i = __import__(__site__, fromlist=[''])
                            if i:
                                order = 999
                                try:
                                    if i.order:
                                        if not isinstance(i.order, int):
                                            try: order = int(i.order)
                                            except: order = 999
                                        else: order = i.order
                                except: pass
                                __item_list__.append((order, {'mode': 'main', 'title': i.title, 'content': '',
                                                              'site': __site__, 'cover_url': a.image(i.image),
                                                              'backdrop_url': a.art(i.art), 'type': 3}))
                        except: pass
                    if __item_list__:
                        __item_list__ = sorted(__item_list__, key=lambda __item__: __item__[0])
                        for __item__ in __item_list__:
                            __site_list__.extend([__item__[1]])
                    if __site_list__:
                        __site_list__.extend([a.menu_separator()])
                        __site_list__.extend([a.lock_toggle()])
                        __site_list__.extend([a.developer_home()])
                        a.add_items(__site_list__)
                        a.end_of_directory()
                    else: a.error(a.language(30907) + ' ' + a.name)
    elif __param__ == 'developer_home':
        try: a.execute(__params__['url'])
        except: pass
    elif __param__ == 'lock_password':
        try: a.change_password()
        except: a.alert(a.language(30908))
    elif __param__ == 'lock_toggle':
        try: a.toggle_lock()
        except: a.alert(a.language(30908))
    elif __param__ == 'clear_cookies':
        try: a.clear_cookies()
        except: a.alert(a.language(30914))
    elif __param__ == 'separator':
        pass
    else:
        __check_ = False
        if a.is_locked():
            __check_ = a.toggle_lock()
        else: __check_ = True
        if __check_:
            try:
                i = __import__(__param__, fromlist=[''])
                i.Site(__params__)
            except ImportError: a.error(a.language(30907) + ' ' + __param__)
