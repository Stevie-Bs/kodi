# -*- coding: UTF-8 -*-
"""
    Add-on Init v.0.0.1
    - Add all .py files in __path__ to __ALL__ for Personal Kodi Add-ons
     
    Copyright (C) 2014  smokdpi

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import os
import re
import xbmc
import xbmcaddon


__path__ = xbmc.translatePath(os.path.join(xbmc.translatePath('special://home'), 'addons',
                              xbmcaddon.Addon().getAddonInfo('id'), 'resources', 'lib'))
__files__ = []

for __file__ in os.listdir(__path__):
    if os.path.isfile(os.path.join(__path__, __file__)):
        __file__ = re.search('^([a-zA-Z0-9]+[a-zA-Z0-9_\-]+)\.py$', __file__)
        if __file__:
            __files__.extend([__file__.groups()[0]])

__ALL__ = __files__