# -*- coding: UTF-8 -*-
"""
    Copyright (C) 2014  smokdpi

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

""" Site information used for main menu if more than 1 site """
title = 'ZeroCast'
image = 'zerocast-icon.png'
art = 'zerocast-fanart.jpg'
order = 1


class Site:
    def __init__(self, params):
        import re
        from addon import Addon
        from addondict import AddonDict as XBMCDict
        from BeautifulSoup import BeautifulSoup, SoupStrainer, Comment

        a = Addon()
        site = self.__module__
        mode = params['mode']

        home_url = 'http://zerocast.tv/channels/'

        if mode == 'main':
            item_list = [{'site': site, 'mode': 'list', 'title': a.language(30001), 'content': '',
                          'cover_url': a.image('channels.png', image),
                          'backdrop_url': a.art(), 'type': 3}]
            item_list.extend(a.favs_hist_menu(site))
            item_list.extend(a.extended_menu())
            a.add_items(item_list)
            a.end_of_directory()

        elif mode == 'list':
            html = a.get_page(home_url)
            soup = BeautifulSoup(html, parseOnlyThese=SoupStrainer('body'), convertEntities=BeautifulSoup.HTML_ENTITIES)
            item_list = []
            params['context'] = 0
            params['content'] = 'tvshows'
            params['mode'] = 'play'
            xbmcdict = XBMCDict().update(params)
            for p in soup.findAll('p'):
                check = p.find('a', href=True)
                if check:
                    _dict = xbmcdict.copy()
                    _dict['url'] = p.a.get('href')
                    item_title = a.language(30100)
                    img = p.find('img', {'src': True})
                    if img:
                        img = img.get('src').replace('./', home_url)
                        r = re.search('.+/(.+?)\.[jpgneif]+', img)
                        if r:
                            item_title = r.group(1)
                    else:
                        img = ''
                    _dict['cover_url'] = img
                    _dict['thumb_url'] = _dict['cover_url']
                    _dict['banner_url'] = _dict['cover_url']
                    _dict['poster'] = _dict['cover_url']
                    _dict['title'] = item_title.replace('-tv', '').upper()
                    _dict['tvshowtitle'] = _dict['title']
                    _dict['originaltitle'] = _dict['title']
                    _dict['sub_site'] = site
                    item_list.extend([_dict])
            if item_list:
                a.add_items(item_list)
                a.end_of_directory()

        elif mode == 'play':
            from playback import Playback
            Playback().play_this(params['url'], params['title'], params['cover_url'])
