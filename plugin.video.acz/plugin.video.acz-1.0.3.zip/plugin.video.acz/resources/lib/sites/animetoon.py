# -*- coding: UTF-8 -*-
"""
    Copyright (C) 2014  smokdpi

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

""" Site information used for main menu if more than 1 site """
title = 'AnimeToon'
order = 2
image = 'animetoon-icon.png'
art = 'animetoon-fanart.jpg'


class Site:
    def __init__(self, params):
        import re
        import time
        from datetime import datetime
        from addon import Addon
        from addondict import AddonDict
        from BeautifulSoup import BeautifulSoup, SoupStrainer, Comment

        addon = Addon()
        site = self.__module__
        mode = params['mode']
        home_url = 'http://www.animetoon.eu/'
        popular_series_url = home_url + 'popular-list/'
        random_url = home_url + 'toon-random/'
        search_url = home_url + 'toon/search?key='
        dubbed_anime_url = 'dubbed-anime'
        cartoons_url = 'cartoon'
        movies_url = 'movies'

        if mode == 'main':
            item_list = [{'site': site, 'mode': 'sub', 'title': addon.language(30001), 'content': '',
                          'url': dubbed_anime_url, 'cover_url': addon.image('dubbedanime.png', image),
                          'backdrop_url': addon.art(), 'type': 3},
                         {'site': site, 'mode': 'sub', 'title': addon.language(30002), 'content': '',
                          'url': cartoons_url, 'cover_url': addon.image('cartoons.png', image),
                          'backdrop_url': addon.art(), 'type': 3},
                         {'site': site, 'mode': 'sub', 'title': addon.language(30003), 'content': '',
                          'url': movies_url, 'cover_url': addon.image('movies.png', image),
                          'backdrop_url': addon.art(), 'type': 3},
                         {'site': site, 'mode': 'list_series', 'title': addon.language(30004), 'content': 'tvshows',
                          'url': popular_series_url, 'cover_url': addon.image('popularseries.png', image),
                          'backdrop_url': addon.art(), 'type': 3},
                         {'site': site, 'mode': 'list_episodes', 'title': addon.language(30006), 'url': random_url,
                          'content': 'tvshows', 'cover_url': addon.image('surpriseme.png', image),
                          'backdrop_url': addon.art(), 'type': 3},
                         {'site': site, 'mode': 'list_series', 'title': addon.language(30015), 'url': search_url,
                          'content': 'search', 'cover_url': addon.image('search.png', image),
                          'backdrop_url': addon.art(), 'type': 3}]
            item_list.extend(addon.favs_hist_menu(site))
            item_list.extend(addon.extended_menu())
            addon.add_items(item_list)
            addon.end_of_directory()

        elif mode == 'sub':
            if params['url'] != 'movies':
                content = 'tvshows'
            else:
                content = 'movies'
            item_list = [{'site': site, 'mode': 'list_index', 'url': home_url + params['url'] + '/',
                          'content': '', 'title': addon.language(30008),
                          'cover_url': addon.image(addon.language(30008) + '.png', image),
                          'backdrop_url': addon.art(), 'type': 3},
                         {'site': site, 'mode': 'az', 'url': home_url + 'alpha-' + params['url'] + '/',
                          'content': '', 'title': addon.language(30007),
                          'cover_url': addon.image(addon.language(30007) + '.png', image),
                          'backdrop_url': addon.art(), 'type': 3},
                         {'site': site, 'mode': 'genres',
                          'url': home_url + re.sub('movies', 'movie', params['url']) + '-genres/',
                          'content': '', 'title': addon.language(30009),
                          'cover_url': addon.image(addon.language(30009) + '.png', image),
                          'backdrop_url': addon.art(), 'type': 3},
                         {'site': site, 'mode': 'list_series', 'url': home_url + 'popular-' + params['url'] + '/',
                          'content': '', 'title': addon.language(30010),
                          'cover_url': addon.image(addon.language(30010) + '.png', image),
                          'backdrop_url': addon.art(), 'type': 3},
                         {'site': site, 'mode': 'list_series', 'url': home_url + 'new-' + params['url'] + '/',
                          'content': '', 'title': addon.language(30011),
                          'cover_url': addon.image(addon.language(30011) + '.png', image),
                          'backdrop_url': addon.art(), 'type': 3},
                         {'site': site, 'mode': 'list_series', 'url': home_url + 'recent-' + params['url'] + '/',
                          'content': '', 'title': addon.language(30012),
                          'cover_url': addon.image(addon.language(30012) + '.png', image),
                          'backdrop_url': addon.art(), 'type': 3}]
            if content != 'movies':
                item_list.extend([{'site': site, 'mode': 'list_series',
                                   'url': home_url + 'ongoing-' + params['url'] + '/', 'content': '',
                                   'title': addon.language(30013),
                                   'cover_url': addon.image(addon.language(30013) + '.png', image),
                                   'backdrop_url': addon.art(), 'type': 3},
                                  {'site': site, 'mode': 'list_series',
                                   'url': home_url + 'completed-' + params['url'] + '/', 'content': '',
                                   'title': addon.language(30014),
                                   'cover_url': addon.image(addon.language(30014) + '.png', image),
                                   'backdrop_url': addon.art(), 'type': 3}])
            addon.add_items(item_list)
            addon.end_of_directory()

        elif mode == 'az':
            import string
            items = string.ascii_lowercase
            item_list = [{'site': site, 'mode': 'list_series', 'url': params['url'] + 'others/',
                          'content': '', 'title': '#', 'cover_url': addon.image(),
                          'backdrop_url': addon.art(), 'type': 3}]
            for item in items:
                item_list.extend([{'site': site, 'mode': 'list_series', 'url': params['url'] + item + '/',
                                   'content': '', 'title': item.upper(), 'cover_url': addon.image(),
                                   'backdrop_url': addon.art(), 'type': 3}])
            addon.add_items(item_list)
            addon.end_of_directory()

        elif mode == 'genres':
            html = addon.get_page(params['url'])
            soup = BeautifulSoup(html, parseOnlyThese=SoupStrainer('table', id='listing'),
                                 convertEntities=BeautifulSoup.HTML_ENTITIES)
            items = soup.findAll('td', text=re.compile('[0-9+]'))
            item_list = []
            for index, item in enumerate(soup.findAll({'a': True})):
                try:
                    count = int(items[index])
                except:
                    count = 0
                if count > 3:
                    item_list.extend([{'site': site, 'mode': 'list_series', 'url': item.get('href'),
                                       'content': '',
                                       'title': item.contents[0].encode('UTF-8') + ' (' + str(count) + ')',
                                       'cover_url': addon.image(), 'backdrop_url': addon.art(), 'type': 3}])
            if item_list:
                addon.add_items(item_list)
                addon.end_of_directory()

        elif mode == 'list_index':
            if 'movies' not in params['url']:
                params['content'] = 'tvshows'
            else:
                params['content'] = 'movies'
            html = addon.get_page(params['url'])
            soup = BeautifulSoup(html, parseOnlyThese=SoupStrainer('table', 'series_index'),
                                 convertEntities=BeautifulSoup.HTML_ENTITIES)
            item_list = []
            params['context'] = 0
            addondict = AddonDict().update(params)
            for index, item in enumerate(soup.findAll({'a': True})):
                _dict = addondict.copy()
                _dict['mode'] = 'list_episodes'
                if params['content'] == 'movies':
                    _dict['duration'] = '4500'
                _dict['title'] = item.contents[0].encode('UTF-8')
                _dict['url'] = item.get('href')
                _dict['sub_site'] = site
                item_list.extend([_dict])
            if item_list:
                addon.add_items(item_list)
                addon.end_of_directory(default_sort=10)

        elif mode == 'list_series':
            if params.get('content', '') == 'search':
                params['content'] = 'tvshows'
                params['context'] = 0
                item = addon.search_input()
                if item:
                    params['url'] = search_url + item
                else:
                    exit(1)
            if 'movie' not in params['url']:
                params['content'] = 'tvshows'
            else:
                params['content'] = 'movies'
            html = addon.get_page(params['url'])
            soup = BeautifulSoup(html, parseOnlyThese=SoupStrainer('div', 'series_list'),
                                 convertEntities=BeautifulSoup.HTML_ENTITIES)
            item_list = []
            params['context'] = 0
            addondict = AddonDict().update(params)
            for li in soup.findAll({'li': True}):
                if li.h3.a.get('href'):
                    _dict = addondict.copy()
                    _dict['title'] = li.h3.a.contents[0].encode('UTF-8').strip()
                    _dict['tvshowtitle'] = li.h3.a.contents[0].encode('UTF-8').strip()
                    _dict['originaltitle'] = li.h3.a.contents[0].encode('UTF-8').strip()
                    _dict['mode'] = 'list_episodes'
                    item = li.find('span', 'type_indic').contents[0].encode('UTF-8').strip()
                    if 'movie' in item.lower() or re.match('.*movie[^s].*', _dict['title'].lower()):
                        _dict['content'] = 'movies'
                        _dict['duration'] = '4500'
                        _dict['type'] = 0
                        _dict['mode'] = 'play'
                    elif 'movie' in _dict['title'].lower():
                        _dict['content'] = 'movies'
                    elif re.match('.*season\s*[0-9]+.*', _dict['title'].lower()):
                        _dict['season'] = int(re.search('season\s*([0-9]+)', _dict['title'].lower()).group(1))
                    _dict['url'] = li.h3.a.get('href')
                    _dict['cover_url'] = re.sub(r'/small/', '/big/', li.img.get('src'))
                    addondict['thumb_url'] = addondict['cover_url']
                    addondict['banner_url'] = addondict['cover_url']
                    addondict['poster'] = addondict['cover_url']
                    item = re.search('\s*(.+?)\s+\[', li.find('div', 'descr').contents[0].encode('UTF-8').strip())
                    if item:
                        _dict['plotoutline'] = item.group(1)
                        _dict['plot'] = item.group(1)
                    items = li.findAll('span', 'bold')
                    _dict['status'] = items[0].contents[0].encode('UTF-8').strip()
                    try:
                        _dict['year'] = int(items[1].contents[0].encode('UTF-8').strip())
                    except:
                        pass
                    item = re.search('^(?:([0-9\.]+)|na)(?:/10)*\s+\(([0-9]+)\s+votes\s*\)$',
                                     items[2].contents[0].encode('UTF-8').strip().lower())
                    if item:
                        try:
                            _dict['rating'] = float(item.group(1))
                        except:
                            pass
                        _dict['votes'] = item.group(2) + ' votes'
                    _dict['sub_site'] = site
                    item_list.extend([_dict])
            soup = BeautifulSoup(html, parseOnlyThese=SoupStrainer('ul', 'pagination'))
            item = soup.find('a', text='Prev')
            if item:
                item_list.extend([{'site': site, 'mode': 'list_series', 'url': item.parent.get('href'),
                                   'content': params['content'], 'title': '  ' + addon.language(30017, True),
                                   'cover_url': addon.image(), 'backdrop_url': addon.art(), 'type': 3}])
            item = soup.find('a', text='Next')
            if item:
                item_list.extend([{'site': site, 'mode': 'list_series', 'url': item.parent.get('href'),
                                   'content': params['content'], 'title': '  ' + addon.language(30018, True),
                                   'cover_url': addon.image(), 'backdrop_url': addon.art(), 'type': 3}])
            if item_list:
                addon.add_items(item_list)
                addon.end_of_directory()

        elif mode == 'list_episodes':
            if 'movie' not in params['url']:
                params['content'] = 'tvshows'
            else:
                params['content'] = 'movies'
            html = addon.get_page(params['url'])
            soup = BeautifulSoup(html, parseOnlyThese=SoupStrainer('div', {'id': 'series_info'}),
                                 convertEntities=BeautifulSoup.HTML_ENTITIES)
            item = soup.find('span', text='Category:').findNext('a').contents[0].encode('UTF-8').strip()
            params['context'] = 0
            if ('movie' in item.lower()) or ('movie' in params['title'].lower()):
                params['content'] = 'movies'
                params['duration'] = '4500'
            else:
                params['content'] = 'episodes'
            params['type'] = 0
            item_list = []
            addondict = AddonDict().update(params)
            addondict['mode'] = 'play'
            addondict['cover_url'] = soup.find('img').get('src')
            addondict['thumb_url'] = addondict['cover_url']
            addondict['banner_url'] = addondict['cover_url']
            addondict['poster'] = addondict['cover_url']
            addondict['tvshowtitle'] = soup.find('h1').contents[0].encode('UTF-8').strip()
            addondict['originaltitle'] = soup.find('h1').contents[0].encode('UTF-8').strip()
            addondict['status'] = soup.find('span', text='Status:').next.strip()
            try:
                addondict['year'] = int(soup.find('span', text='Released:').next.strip())
            except:
                pass
            try:
                addondict['rating'] = float(soup.find('span', {'id': 'rating_num'}).contents[0].encode('UTF-8').strip())
            except:
                pass
            addondict['votes'] = soup.find('span', {'id': 'votes'}).contents[0].encode('UTF-8').strip() + ' votes'
            item = soup.find('span', {'id': 'brief_notes'})
            if item:
                addondict['plotoutline'] = soup.find('span', {'id': 'brief_notes'}).contents[0].encode('UTF-8').strip()
                addondict['plot'] = soup.find('span', {'id': 'full_notes'}).contents[0].encode('UTF-8').strip()
            else:
                addondict['plotoutline'] = \
                    soup.find('span', text='Description:').findNext('div').contents[0].encode('UTF-8').strip()
                addondict['plot'] = \
                    soup.find('span', text='Description:').findNext('div').contents[0].encode('UTF-8').strip()
            addondict['genre'] = ', '.join([item.contents[0].encode('UTF-8')
                                            for item in soup.find('span', text='Genres:').findAllNext('a')])
            soup = BeautifulSoup(html, parseOnlyThese=SoupStrainer('div', {'id': 'videos'}),
                                 convertEntities=BeautifulSoup.HTML_ENTITIES)
            items = soup.findAll('span', 'right_text')
            for index, item in enumerate(soup.findAll('a', {'href': True})):
                _dict = addondict.copy()
                _dict['title'] = item.contents[0].encode('UTF-8').strip()
                _dict['url'] = item.get('href')
                item = items[index].contents[0].encode('UTF-8').strip()
                _dict['date'] = datetime(*(time.strptime(item, '%b %d, %Y')[0:6])).strftime("%d.%m.%Y")
                if re.match('.*episode\s*[0-9]+.*', _dict['title'].lower()):
                    _dict['episode'] = int(re.search('episode\s*([0-9]+)', _dict['title'].lower()).group(1))
                    if re.match('.*season\s*[0-9]+.*', _dict['title'].lower()):
                        _dict['season'] = int(re.search('season\s*([0-9]+)', _dict['title'].lower()).group(1))
                    try:
                        if int(_dict['season']) == 0: _dict['season'] = 1
                    except:
                        pass
                _dict['sub_site'] = site
                item_list.extend([_dict])
            while True:
                soup = BeautifulSoup(html, parseOnlyThese=SoupStrainer('ul', 'pagination'))
                item = soup.find('a', text='Next')
                if not item:
                    break
                html = addon.get_page(item.parent.get('href'))
                soup = BeautifulSoup(html, parseOnlyThese=SoupStrainer('div', {'id': 'videos'}),
                                     convertEntities=BeautifulSoup.HTML_ENTITIES)
                for index, item in enumerate(soup.findAll('a', {'href': True})):
                    _dict = addondict.copy()
                    _dict['title'] = item.contents[0].encode('UTF-8').strip()
                    _dict['url'] = item.get('href')
                    item = items[index].contents[0].encode('UTF-8').strip()
                    _dict['date'] = datetime(*(time.strptime(item, '%b %d, %Y')[0:6])).strftime("%d.%m.%Y")
                    if re.match('.*episode\s*[0-9]+.*', _dict['title'].lower()):
                        _dict['episode'] = int(re.search('episode\s*([0-9]+)', _dict['title'].lower()).group(1))
                        if re.match('.*season\s*[0-9]+.*', _dict['title'].lower()):
                            _dict['season'] = int(re.search('season\s*([0-9]+)', _dict['title'].lower()).group(1))
                        try:
                            if int(_dict['season']) == 0: _dict['season'] = 1
                        except:
                            pass
                    _dict['sub_site'] = site
                    item_list.extend([_dict])
            if item_list:
                addon.add_items(item_list)
                addon.end_of_directory(default_sort=10)

        elif mode == 'play':
            html = addon.get_page(params['url'])
            if params['content'] == 'movies':
                soup = BeautifulSoup(html, parseOnlyThese=SoupStrainer('div', {'id': 'videos'}),
                                     convertEntities=BeautifulSoup.HTML_ENTITIES)
                item = soup.find('a', {'href': True})
                if item: params['url'] = item.get('href')
            html = addon.get_page(params['url'])
            soup = BeautifulSoup(html, parseOnlyThese=SoupStrainer('div', {'id': 'streams'}),
                                 convertEntities=BeautifulSoup.HTML_ENTITIES)
            item_list = []
            addondict = AddonDict().update(params)
            for items in soup.findAll('div', 'vmargin'):
                _dict = addondict.copy()
                item = items.find('iframe')
                if items.find('ul', 'part_list'):
                    _dict['multi-part'] = True
                    _dict['parts'] = []
                    _dict['url'] = ''
                    for index, li in enumerate(items.ul.findAll('li')):
                        compiled = re.compile(r'(part.*?)[1-9]', re.IGNORECASE)
                        _dict['parts'].extend(
                            [compiled.sub('\g<01>' + str(index + 1), item.get('src')).encode('UTF-8')])
                    item_list.extend([_dict])
                else:
                    _dict['url'] = item.get('src')
                    item_list.extend([_dict])
            if item_list:
                from playback import Playback
                Playback().choose_sources(item_list)
            else:
                addon.alert(addon.language(30904, True))
